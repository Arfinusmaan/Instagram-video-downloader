import express from 'express';
import cors from 'cors';
import { spawn } from 'child_process';
import {
  createReadStream, existsSync, mkdirSync, unlinkSync,
  statSync, readdirSync, renameSync
} from 'fs';
import { join, extname, basename } from 'path';
import { fileURLToPath } from 'url';
import { dirname } from 'path';
import { tmpdir } from 'os';
import ffmpegPath from 'ffmpeg-static';

const __filename = fileURLToPath(import.meta.url);
const __dirname  = dirname(__filename);

const app  = express();
const PORT = 3001;

// Temp folder for yt-dlp downloads
const TEMP_DIR = join(tmpdir(), 'omnistream_4k');
if (!existsSync(TEMP_DIR)) mkdirSync(TEMP_DIR, { recursive: true });

app.use(cors({ origin: '*' }));
app.use(express.json({ limit: '10mb' }));

console.log(`[INIT] FFmpeg location: ${ffmpegPath || 'None'}`);

// ─── Helpers ─────────────────────────────────────────────────────────────────

/** Find the best matching file in TEMP_DIR for `prefix` (filtering out temp/incomplete files) */
function findFile(prefix, isAudio = false) {
  try {
    const all = readdirSync(TEMP_DIR);
    // Ignore .part, .ytdl, .temp files
    const valid = all.filter(f => 
      f.startsWith(prefix) && 
      !f.endsWith('.part') && 
      !f.endsWith('.ytdl') && 
      !f.endsWith('.temp')
    );

    if (!valid.length) return null;

    if (isAudio) {
      const audioMatch = valid.find(f => /\.(mp3|m4a|aac|opus|ogg|wav)$/i.test(f));
      if (audioMatch) return join(TEMP_DIR, audioMatch);
    } else {
      // Prioritize full video containers
      const vidMatch = valid.find(f => /\.(mp4|mkv|webm|mov)$/i.test(f));
      if (vidMatch) return join(TEMP_DIR, vidMatch);
    }

    // Fallback: pick the largest file (prevents picking an 87KB audio stream over the video file!)
    const sorted = valid
      .map(f => {
        try { return { name: f, size: statSync(join(TEMP_DIR, f)).size }; }
        catch { return { name: f, size: 0 }; }
      })
      .sort((a, b) => b.size - a.size);

    return sorted.length > 0 ? join(TEMP_DIR, sorted[0].name) : null;
  } catch {
    return null;
  }
}

/** Run yt-dlp, collect all JSONL lines, return array of objects */
function ytDlpJsonLines(args) {
  return new Promise((resolve, reject) => {
    const finalArgs = [...args];
    if (ffmpegPath && existsSync(ffmpegPath)) {
      finalArgs.unshift('--ffmpeg-location', ffmpegPath);
    }
    const proc = spawn('yt-dlp', finalArgs, { stdio: ['ignore', 'pipe', 'pipe'] });
    let stdout = '';
    let stderr = '';
    proc.stdout.on('data', d => (stdout += d.toString()));
    proc.stderr.on('data', d => (stderr += d.toString()));
    proc.on('close', code => {
      const lines = stdout.trim().split('\n').filter(Boolean);
      const objects = [];
      for (const line of lines) {
        try { objects.push(JSON.parse(line)); } catch (_) {}
      }
      
      if (objects.length > 0) {
        resolve(objects);
      } else if (code !== 0) {
        reject(new Error(stderr.trim() || `yt-dlp exited ${code}`));
      } else {
        reject(new Error('yt-dlp returned no metadata'));
      }
    });
    proc.on('error', () => reject(new Error('yt-dlp not found on system.')));
  });
}

/** Spawn yt-dlp download, resolve with final file path */
function ytDlpDownload(args, prefix, isAudio = false) {
  return new Promise((resolve, reject) => {
    const finalArgs = [...args];
    if (ffmpegPath && existsSync(ffmpegPath)) {
      finalArgs.unshift('--ffmpeg-location', ffmpegPath);
    }

    const proc = spawn('yt-dlp', finalArgs, { stdio: ['ignore', 'pipe', 'pipe'] });
    let stderr = '';
    proc.stderr.on('data', d => { stderr += d.toString(); process.stderr.write(d); });
    proc.stdout.on('data', () => {}); // drain stdout
    proc.on('error', () => reject(new Error('yt-dlp not found. Please verify python yt-dlp.')));
    proc.on('close', code => {
      // Even if exit code is non-zero, check if the downloaded file exists and is healthy
      const candidate = findFile(prefix, isAudio);
      if (candidate && existsSync(candidate)) {
        try {
          const sz = statSync(candidate).size;
          if (sz > 5000) return resolve(candidate); // healthy file found
        } catch (_) {}
      }

      if (code !== 0) {
        return reject(new Error(parseError(stderr) || `yt-dlp error (code ${code})`));
      }
      
      if (candidate && existsSync(candidate)) return resolve(candidate);
      reject(new Error('File not found after download. Please try a different quality or link.'));
    });
  });
}

/** Build quality format selector with progressive MP4 fallback */
function fmtFor(id) {
  const m = {
    '4k':       'bestvideo[height<=2160]+bestaudio/bestvideo[height<=2160]/best[height<=2160][ext=mp4]/best',
    '2k':       'bestvideo[height<=1440]+bestaudio/bestvideo[height<=1440]/best[height<=1440][ext=mp4]/best',
    '1080p':    'bestvideo[height<=1080]+bestaudio/bestvideo[height<=1080]/best[height<=1080][ext=mp4]/best',
    '720p':     'best[height<=720][ext=mp4]/bestvideo[height<=720]+bestaudio/best',
    'audio-320':'bestaudio/best',
  };
  return m[id] || m['4k'];
}

/** Convert raw yt-dlp stderr to user-friendly message */
function parseError(raw = '') {
  const s = raw.toLowerCase();
  if (s.includes('yt-dlp not found') || s.includes('not recognized')) return 'yt-dlp not found. Please install yt-dlp.';
  if (s.includes('login') || s.includes('cookie') || s.includes('sign in')) return 'This media requires account login. Only public content is supported.';
  if (s.includes('private') || s.includes('not available')) return 'This content is private or unavailable.';
  if (s.includes('no video') || s.includes('no media') || s.includes('not supported')) return 'No downloadable media found at this URL.';
  if (s.includes('rate limit') || s.includes('429')) return 'Rate-limited by platform. Wait a minute and try again.';
  if (s.includes('geo') || s.includes('not available in your country')) return 'This media is geo-blocked in your region.';
  if (s.includes('unsupported url')) return 'Unsupported URL. Please paste a valid video or reel link.';
  if (raw.trim()) return raw.trim().split('\n').pop().slice(0, 180);
  return 'Download failed. Try a different format.';
}

/** Human-readable duration from seconds */
function fmtDur(s) {
  if (!s) return '0:00';
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  const sec = Math.floor(s % 60);
  return h > 0
    ? `${h}:${String(m).padStart(2,'0')}:${String(sec).padStart(2,'0')}`
    : `${m}:${String(sec).padStart(2,'0')}`;
}

function fmtCount(n) {
  if (!n) return null;
  if (n >= 1e9) return `${(n/1e9).toFixed(1)}B`;
  if (n >= 1e6) return `${(n/1e6).toFixed(1)}M`;
  if (n >= 1e3) return `${(n/1e3).toFixed(1)}K`;
  return String(n);
}

function fmtBytes(b) {
  if (!b) return null;
  const mb = b / 1024 / 1024;
  return mb >= 1024 ? `${(mb/1024).toFixed(1)} GB` : `${mb.toFixed(1)} MB`;
}

function detectPlatform(url = '') {
  const u = url.toLowerCase();
  if (u.includes('instagram.com') || u.includes('instagr.am'))
    return { id:'instagram', name:'Instagram', gradient:'linear-gradient(135deg,#fd1d1d,#e1306c,#833ab4)' };
  if (u.includes('youtube.com') || u.includes('youtu.be'))
    return { id:'youtube', name:'YouTube', gradient:'linear-gradient(135deg,#ff0000,#cc0000)' };
  if (u.includes('facebook.com') || u.includes('fb.watch') || u.includes('fb.com'))
    return { id:'facebook', name:'Facebook', gradient:'linear-gradient(135deg,#0064e0,#00c6ff)' };
  if (u.includes('tiktok.com'))
    return { id:'tiktok', name:'TikTok', gradient:'linear-gradient(135deg,#010101,#00f2fe)' };
  if (u.includes('twitter.com') || u.includes('x.com'))
    return { id:'twitter', name:'Twitter/X', gradient:'linear-gradient(135deg,#1DA1F2,#14171A)' };
  return { id:'unknown', name:'Universal', gradient:'linear-gradient(135deg,#8b5cf6,#3b82f6)' };
}

function detectMediaType(url = '', info = {}) {
  const u = url.toLowerCase();
  if (u.includes('/reel/') || u.includes('fb.watch') || u.includes('/reels/')) return 'Reel';
  if (u.includes('/shorts/')) return 'Short';
  if (info._type === 'playlist' || info.entries?.length > 1) return 'Carousel';
  if (u.includes('/p/')) return 'Post';
  return 'Video';
}

function buildQualityTiers(formats = []) {
  const video = formats.filter(f => f.vcodec && f.vcodec !== 'none' && f.height);
  const maxH  = video.length ? Math.max(...video.map(f => f.height)) : 1080;
  const tiers = [];

  if (maxH >= 2160) tiers.push({ id:'4k',       label:'4K Ultra HD',         resolution:'3840×2160', fps:'60 FPS', codec:'AV1/VP9/H.264',  bitrate:'45–68 Mbps',  estimatedSize:'~180 MB', audio:'320kbps AAC', isHighest:true,  tag:'MAX 4K' });
  if (maxH >= 1440) tiers.push({ id:'2k',       label:'2K Quad HD',          resolution:'2560×1440', fps:'60 FPS', codec:'VP9/H.264',      bitrate:'25–32 Mbps',  estimatedSize:'~95 MB',  audio:'320kbps AAC', isHighest:false, tag:'QHD'    });
  tiers.push({                   id:'1080p',    label:'Full HD (1080p)',      resolution:'1920×1080', fps:'60 FPS', codec:'H.264 MP4',      bitrate:'8–15 Mbps',   estimatedSize:'~50 MB',  audio:'256kbps AAC', isHighest:false, tag:'FHD'    });
  tiers.push({                   id:'720p',     label:'HD (720p)',            resolution:'1280×720',  fps:'30 FPS', codec:'H.264 MP4',      bitrate:'4–8 Mbps',    estimatedSize:'~25 MB',  audio:'192kbps AAC', isHighest:false, tag:'HD'     });
  tiers.push({                   id:'audio-320',label:'Audio Only (MP3 320kbps)', resolution:'Audio Only', fps:'N/A', codec:'MP3 320kbps', bitrate:'320 kbps',    estimatedSize:'~8 MB',   audio:'48 kHz',      isHighest:false, tag:'MP3'    });

  if (!tiers.some(t => t.isHighest)) tiers[0].isHighest = true;
  return tiers;
}

// Common yt-dlp flags
const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36';

// ─── POST /api/info ───────────────────────────────────────────────────────────
app.post('/api/info', async (req, res) => {
  const { url } = req.body;
  if (!url) return res.status(400).json({ error: 'Missing URL' });
  console.log(`[INFO] ${url}`);

  try {
    let infoObjects;
    try {
      infoObjects = await ytDlpJsonLines([
        '--dump-json',
        '--no-warnings',
        '--user-agent', UA,
        '--yes-playlist',
        url,
      ]);
    } catch (_) {
      infoObjects = await ytDlpJsonLines([
        '--dump-json',
        '--no-warnings',
        '--user-agent', UA,
        '--no-playlist',
        url,
      ]);
    }

    const primary = infoObjects[0];
    const isCarousel = infoObjects.length > 1;

    // Direct stream link discovery (progressive MP4 or primary direct URL)
    const directFormat = (primary.formats || [])
      .slice()
      .reverse()
      .find(f => f.url && f.vcodec !== 'none' && f.acodec !== 'none') || 
      (primary.formats || []).slice().reverse().find(f => f.url && f.vcodec !== 'none') ||
      primary.formats?.[0];

    const directUrl = primary.url || directFormat?.url || '';

    // Build carousel items
    const carouselItems = isCarousel
      ? infoObjects.map((entry, i) => {
          const hasVideo = entry.vcodec && entry.vcodec !== 'none';
          const height   = entry.height || 0;
          const width    = entry.width  || 0;
          const slideDirect = entry.url || entry.thumbnail || entry.thumbnails?.[0]?.url || '';
          return {
            id:         i + 1,
            type:       hasVideo ? 'video' : 'photo',
            title:      entry.title || `Slide ${i + 1}`,
            resolution: width && height ? `${width}×${height}` : 'N/A',
            fps:        entry.fps ? `${Math.round(entry.fps)} fps` : '–',
            size:       fmtBytes(entry.filesize || entry.filesize_approx) || '–',
            thumb:      entry.thumbnail || entry.thumbnails?.[0]?.url || primary.thumbnail || '',
            duration:   hasVideo ? fmtDur(entry.duration) : 'Photo',
            url:        entry.webpage_url || url,
            directUrl:  slideDirect,
          };
        })
      : null;

    // Best thumbnail
    const thumb = (() => {
      const thumbs = primary.thumbnails;
      if (thumbs?.length) {
        const sorted = [...thumbs].sort((a, b) => ((b.width||0)*(b.height||0)) - ((a.width||0)*(a.height||0)));
        return sorted[0]?.url || primary.thumbnail || '';
      }
      return primary.thumbnail || '';
    })();

    const metadata = {
      url,
      title:        primary.title || 'OmniStream Video',
      author:       primary.uploader || primary.channel || primary.creator || 'Creator',
      authorUrl:    primary.uploader_url || primary.channel_url || '',
      duration:     fmtDur(primary.duration),
      views:        primary.view_count ? `${fmtCount(primary.view_count)} views` : null,
      likes:        primary.like_count ? fmtCount(primary.like_count) : null,
      uploadDate:   primary.upload_date
        ? `${primary.upload_date.slice(0,4)}-${primary.upload_date.slice(4,6)}-${primary.upload_date.slice(6,8)}`
        : null,
      thumbnailUrl: thumb,
      description:  (primary.description || '').slice(0, 500),
      platform:     detectPlatform(url),
      mediaType:    detectMediaType(url, { entries: infoObjects }),
      isCarousel,
      carouselItems,
      qualities:    buildQualityTiers(primary.formats || []),
      directUrl:    directUrl,
      extractor:    primary.extractor_key || primary.extractor || '',
      id:           primary.id || '',
    };

    res.json({ success: true, metadata });
  } catch (err) {
    console.error('[INFO ERROR]', err.message);
    res.status(500).json({ error: parseError(err.message) });
  }
});

// ─── POST /api/download ───────────────────────────────────────────────────────
app.post('/api/download', async (req, res) => {
  const { url, qualityId = '4k', audioOnly = false } = req.body;
  if (!url) return res.status(400).json({ error: 'Missing URL' });

  const isAudio = audioOnly || qualityId === 'audio-320';
  const prefix  = `dl_${Date.now()}_${Math.random().toString(36).slice(2,7)}`;
  const outTmpl = join(TEMP_DIR, `${prefix}.%(ext)s`);

  console.log(`[DOWNLOAD] quality=${qualityId} audioOnly=${isAudio} url=${url}`);

  const args = [
    url,
    '-o', outTmpl,
    '--no-playlist',
    '--no-warnings',
    '--user-agent', UA,
  ];

  if (isAudio) {
    args.push('-f', 'bestaudio/best', '--extract-audio', '--audio-format', 'mp3', '--audio-quality', '0');
  } else {
    const fmt = fmtFor(qualityId);
    args.push('-f', fmt, '--merge-output-format', 'mp4');
  }

  try {
    let title = 'video';
    try {
      const info = await ytDlpJsonLines(['--dump-json','--no-playlist','--no-warnings','--user-agent',UA,url]);
      title = (info[0].title || 'video').replace(/[^\w\s\-_.]/g, '').trim().slice(0, 60) || 'video';
    } catch (_) {}

    const filePath = await ytDlpDownload(args, prefix, isAudio);
    const stat     = statSync(filePath);
    const fileExt  = extname(filePath).replace('.','').toLowerCase() || (isAudio ? 'mp3' : 'mp4');
    const mime     = ['mp3','m4a','ogg','opus','aac'].includes(fileExt) ? 'audio/mpeg' : 'video/mp4';
    const dlName   = `${title}_${qualityId}.${fileExt}`;

    res.setHeader('Content-Disposition', `attachment; filename="${dlName}"; filename*=UTF-8''${encodeURIComponent(dlName)}`);
    res.setHeader('Content-Type', mime);
    res.setHeader('Content-Length', stat.size);
    res.setHeader('Access-Control-Expose-Headers', 'Content-Disposition, Content-Length');

    const stream = createReadStream(filePath);
    stream.pipe(res);
    stream.on('close', () => { try { unlinkSync(filePath); } catch(_){} });
    stream.on('error', (e) => {
      console.error('[STREAM ERR]', e);
      try { unlinkSync(filePath); } catch(_){}
    });

  } catch (err) {
    console.error('[DOWNLOAD ERROR]', err.message);
    if (!res.headersSent) res.status(500).json({ error: err.message });
  }
});

// ─── GET /api/stream (Native direct browser download) ──────────────────────────
app.get('/api/stream', async (req, res) => {
  const { url, qualityId = '1080p', audioOnly = 'false' } = req.query;
  if (!url) return res.status(400).send('Missing url parameter');

  const isAudio = audioOnly === 'true' || qualityId === 'audio-320';
  const prefix  = `nat_${Date.now()}_${Math.random().toString(36).slice(2,7)}`;
  const outTmpl = join(TEMP_DIR, `${prefix}.%(ext)s`);

  console.log(`[NATIVE STREAM] quality=${qualityId} url=${url}`);

  const args = [
    url,
    '-o', outTmpl,
    '--no-playlist',
    '--no-warnings',
    '--user-agent', UA,
  ];

  if (isAudio) {
    args.push('-f', 'bestaudio/best', '--extract-audio', '--audio-format', 'mp3', '--audio-quality', '0');
  } else {
    args.push('-f', fmtFor(qualityId), '--merge-output-format', 'mp4');
  }

  try {
    const filePath = await ytDlpDownload(args, prefix, isAudio);
    const stat     = statSync(filePath);
    const fileExt  = extname(filePath).replace('.','').toLowerCase() || (isAudio ? 'mp3' : 'mp4');
    const mime     = ['mp3','m4a','ogg','opus','aac'].includes(fileExt) ? 'audio/mpeg' : 'video/mp4';
    const dlName   = `download_${qualityId}.${fileExt}`;

    res.setHeader('Content-Disposition', `attachment; filename="${dlName}"; filename*=UTF-8''${encodeURIComponent(dlName)}`);
    res.setHeader('Content-Type', mime);
    res.setHeader('Content-Length', stat.size);

    const stream = createReadStream(filePath);
    stream.pipe(res);
    stream.on('close', () => { try { unlinkSync(filePath); } catch(_){} });
  } catch (err) {
    console.error('[NATIVE STREAM ERR]', err.message);
    res.status(500).send(parseError(err.message));
  }
});

// ─── POST /api/carousel-download ─────────────────────────────────────────────
app.post('/api/carousel-download', async (req, res) => {
  const { url, slideIndex = 0, qualityId = '4k' } = req.body;
  if (!url) return res.status(400).json({ error: 'Missing URL' });

  const isAudio  = qualityId === 'audio-320';
  const prefix   = `slide_${Date.now()}_${Math.random().toString(36).slice(2,7)}`;
  const outTmpl  = join(TEMP_DIR, `${prefix}.%(ext)s`);
  const slideNum = slideIndex + 1;

  console.log(`[CAROUSEL-DL] slide=${slideNum} quality=${qualityId} url=${url}`);

  const args = [
    url,
    '-o', outTmpl,
    '--no-warnings',
    '--user-agent', UA,
    '--playlist-items', String(slideNum),
  ];

  if (isAudio) {
    args.push('-f','bestaudio/best','--extract-audio','--audio-format','mp3','--audio-quality','0');
  } else {
    args.push('-f', fmtFor(qualityId), '--merge-output-format', 'mp4');
  }

  try {
    const filePath = await ytDlpDownload(args, prefix, isAudio);
    const stat     = statSync(filePath);
    const fileExt  = extname(filePath).replace('.','').toLowerCase() || 'mp4';
    const mime     = ['jpg','jpeg','png','webp'].includes(fileExt)
      ? `image/${fileExt}`
      : ['mp3','m4a','aac'].includes(fileExt) ? 'audio/mpeg' : 'video/mp4';

    const dlName = `slide_${slideNum}.${fileExt}`;
    res.setHeader('Content-Disposition', `attachment; filename="${dlName}"; filename*=UTF-8''${encodeURIComponent(dlName)}`);
    res.setHeader('Content-Type', mime);
    res.setHeader('Content-Length', stat.size);
    res.setHeader('Access-Control-Expose-Headers', 'Content-Disposition, Content-Length');

    const stream = createReadStream(filePath);
    stream.pipe(res);
    stream.on('close', () => { try { unlinkSync(filePath); } catch(_){} });
  } catch (err) {
    console.error('[CAROUSEL-DL ERROR]', err.message);
    if (!res.headersSent) res.status(500).json({ error: parseError(err.message) });
  }
});

// ─── GET /api/health ──────────────────────────────────────────────────────────
app.get('/api/health', (_req, res) => {
  const proc = spawn('yt-dlp', ['--version'], { stdio: ['ignore','pipe','pipe'] });
  let version = '';
  proc.stdout.on('data', d => (version += d.toString().trim()));
  proc.on('close', code => {
    res.json({
      status: 'ok',
      ytdlp: code === 0,
      ytdlpVersion: version || 'unknown',
      ffmpeg: Boolean(ffmpegPath && existsSync(ffmpegPath)),
      ffmpegPath: ffmpegPath || null,
    });
  });
  proc.on('error', () => {
    res.json({ status: 'ok', ytdlp: false, ytdlpVersion: null, ffmpeg: false });
  });
});

// ─── Start ────────────────────────────────────────────────────────────────────
app.listen(PORT, '0.0.0.0', () => {
  console.log(`\n  🚀  OmniStream 4K Backend  →  http://localhost:${PORT}`);
  console.log(`  📂  Temp folder: ${TEMP_DIR}`);
  console.log(`  🎬  FFmpeg: ${ffmpegPath || 'NOT FOUND'}\n`);
});
